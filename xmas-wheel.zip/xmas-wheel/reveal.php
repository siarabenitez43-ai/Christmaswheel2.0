<?php
// Returns a pick only to the authorized person (ADMIN_EMAIL).
require 'config.php';
header('Content-Type: application/json');
if (empty($_SESSION['uid'])) { http_response_code(401); echo json_encode(['error' => 'Please log in.']); exit; }
if (empty($_SESSION['is_admin'])) {
    http_response_code(403); echo json_encode(['error' => 'Only the authorized person can reveal the nabunot.']); exit;
}
$target = (int)($_GET['user_id'] ?? 0);
$stmt = $con->prepare('SELECT u.username, p.picked_name FROM users u JOIN picks p ON p.user_id=u.id WHERE u.id=?');
$stmt->bind_param('i', $target);
$stmt->execute();
$r = $stmt->get_result()->fetch_assoc();
echo json_encode($r ? ['username' => $r['username'], 'picked' => $r['picked_name']] : ['error' => 'No pick yet.']);
