-- FRESH INSTALL (drops the old database first, so only run this on a new/test setup)
DROP DATABASE IF EXISTS xmas_wheel;
CREATE DATABASE xmas_wheel CHARACTER SET utf8mb4;
USE xmas_wheel;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  is_admin TINYINT(1) NOT NULL DEFAULT 0   -- not used; the reveal permission comes from ADMIN_EMAIL in app_settings.php
);

-- MASTER LIST: the names on the wheel. A name is DELETED from here when someone picks it.
CREATE TABLE names (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL
);

-- RESULTS: who picked which name (one pick per user). Shown as "nabunot" in the table.
CREATE TABLE picks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  picked_name VARCHAR(80) NOT NULL,
  picked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Replace with your real participants
INSERT INTO names (name) VALUES ('Anna'),('Ben'),('Carla'),('David'),('Ella'),('Francis'),('Grace'),('Henry');

/* ---------------------------------------------------------------
   ALREADY HAVE THE OLD DATABASE? Run this block instead of the above:

   CREATE TABLE picks (
     id INT AUTO_INCREMENT PRIMARY KEY,
     user_id INT NOT NULL UNIQUE,
     picked_name VARCHAR(80) NOT NULL,
     picked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
   );
   INSERT INTO picks (user_id, picked_name) SELECT picked_by, name FROM names WHERE picked_by IS NOT NULL;
   DELETE FROM names WHERE picked_by IS NOT NULL;
   ALTER TABLE names DROP FOREIGN KEY names_ibfk_1;
   ALTER TABLE names DROP COLUMN picked_by;
--------------------------------------------------------------- */
