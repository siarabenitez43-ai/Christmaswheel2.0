<?php
// Email (SMTP) settings, the authorized reveal account, and send_mail().
/* ---- Email settings (Gmail example) ----
   1. Turn on 2-Step Verification in your Google account.
   2. Create an App Password: https://myaccount.google.com/apppasswords
   3. Paste your Gmail address and the 16-character app password below.
   Leave SMTP_USER empty to use PHP's mail() instead (usually doesn't work on XAMPP). */
const SMTP_HOST = 'smtp.gmail.com';
const SMTP_PORT = 465;
const SMTP_USER = '';
const SMTP_PASS = '';
const MAIL_FROM_NAME = 'Christmas Wheel';

// Only this account can reveal the nabunot
const ADMIN_EMAIL = 'siarabenitez43@gmail.com';

function send_mail($to, $subject, $body) {
    if (SMTP_USER === '') {
        return @mail($to, $subject, $body, "From: no-reply@localhost\r\nContent-Type: text/plain; charset=UTF-8");
    }
    $ctx = stream_context_create(['ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]); // local XAMPP has no CA bundle
    $fp = @stream_socket_client('ssl://' . SMTP_HOST . ':' . SMTP_PORT, $en, $es, 15, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) return false;
    $read = function () use ($fp) {
        $r = '';
        while ($l = fgets($fp, 515)) { $r .= $l; if (substr($l, 3, 1) === ' ') break; }
        return $r;
    };
    $cmd = function ($c) use ($fp, $read) { fwrite($fp, $c . "\r\n"); return $read(); };
    $read();
    $cmd('EHLO localhost');
    $cmd('AUTH LOGIN');
    $cmd(base64_encode(SMTP_USER));
    $r = $cmd(base64_encode(SMTP_PASS));
    if (strpos($r, '235') !== 0) { fclose($fp); return false; }
    $cmd('MAIL FROM:<' . SMTP_USER . '>');
    $cmd('RCPT TO:<' . $to . '>');
    $cmd('DATA');
    $msg = 'From: ' . MAIL_FROM_NAME . ' <' . SMTP_USER . ">\r\nTo: $to\r\n"
         . 'Subject: =?UTF-8?B?' . base64_encode($subject) . "?=\r\nMIME-Version: 1.0\r\n"
         . "Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
         . chunk_split(base64_encode($body));
    $r = $cmd($msg . "\r\n.");
    $cmd('QUIT');
    fclose($fp);
    return strpos($r, '250') === 0;
}
